SERVICIO LECTOR RFID

REQUERIMIENTOS

1- sudo apt install default-jre

2- sudo apt install default-jdk

3- Conexion LAN en PRIMER puerto

4- IPv4 manual LAN 192.168.1.201


CONFIGURACION

1- Descarga el proyecto LECTOR_RFID en /home/user/

2- Otorga permisos completos al directorio
 
2- Crear archivo de servicio /etc/systemd/system/reader.service con siguiente contenido

  [Unit]
  Description= reader script

  [Service]
  ExecStart=/home/user/LECTOR_RFID/start_lector.sh

  [Install]
  WantedBy=multi-user.target
  
4- systemctl enable reader , esto habilita el servicio para el booteo 

5- En config.properties van los datos propios de cada cabina, el nombre de usuario(id_cabina) y contraseña(KxZVM@&0$SOx_ + id_Cabina) la cual debe existir en el servidor. Ademas se configura la ip del servidor y ruta para el archivo log, con un limite en cantidad de bytes.
 
ACTUALIZACION AUTOMATICA

https://securityhacklabs.net/articulo/como-montar-su-propio-servidor-git , hay muchos tutoriales de como hacer esto

1- Crear un usuario servidor Git

2- Dentro crear un repositorio .git, que tenga el lector.jar con start_lector.sh para el servicio, el config.properties y el log deben ignorarse ya que varian en cada cabina.

2- Crar una clave SSH para la cabina

3- Autorizar en el servidor git la clave SSH de la cabina

4- En start_lector.sh agregar un git pull de nuestro servidor creado antes de ejectuar el jar.

De esta forma el servicio con git pull trae los ultimos cambios del servidor antes de arrancar el lector.

  

