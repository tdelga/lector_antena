#!/bin/bash

sleep 30
java -jar /home/user/LECTOR_RFID/Lector_v1.0.jar
